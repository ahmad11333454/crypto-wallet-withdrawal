// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC20Burnable} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import {ERC20Permit} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";

/// @title NovaToken
/// @notice Fixed-supply ERC-20. No mint function exists after deployment.
contract NovaToken is ERC20, ERC20Burnable, ERC20Permit {
    uint256 public constant TOTAL_SUPPLY = 100_000_000 * 10 ** 18;

    constructor(address treasury)
        ERC20("Nova Token", "NOVA")
        ERC20Permit("Nova Token")
    {
        require(treasury != address(0), "Treasury cannot be zero address");
        _mint(treasury, TOTAL_SUPPLY);
    }
}
