// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/// @title NovaTokenVesting
/// @notice Immutable-per-beneficiary linear vesting after a configurable cliff.
/// @dev The owner can create a schedule, but cannot edit, revoke, or withdraw beneficiary allocations.
contract NovaTokenVesting is Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    IERC20 public immutable token;

    struct VestingSchedule {
        uint256 totalAmount;
        uint256 released;
        uint64 startTime;
        uint64 cliffDuration;
        uint64 vestingDuration;
    }

    mapping(address => VestingSchedule) public schedules;

    // Total amounts ever assigned to schedules and total amounts released.
    // Outstanding obligations = totalAllocated - totalReleased.
    uint256 public totalAllocated;
    uint256 public totalReleased;

    event ScheduleCreated(
        address indexed beneficiary,
        uint256 amount,
        uint64 startTime,
        uint64 cliffDuration,
        uint64 vestingDuration
    );
    event TokensReleased(address indexed beneficiary, uint256 amount);

    constructor(address tokenAddress, address initialOwner) Ownable(initialOwner) {
        require(tokenAddress != address(0), "Token address cannot be zero");
        require(initialOwner != address(0), "Owner cannot be zero");
        token = IERC20(tokenAddress);
    }

    function createSchedule(
        address beneficiary,
        uint256 amount,
        uint64 startTime,
        uint64 cliffDuration,
        uint64 vestingDuration
    ) external onlyOwner {
        require(beneficiary != address(0), "Beneficiary cannot be zero address");
        require(amount > 0, "Amount must be greater than zero");
        require(vestingDuration > 0, "Vesting duration must be greater than zero");
        require(schedules[beneficiary].totalAmount == 0, "Schedule already exists");

        // Do time arithmetic in uint256 to make overflow checks explicit.
        uint256 cliffEnd = uint256(startTime) + uint256(cliffDuration);
        uint256 vestingEnd = cliffEnd + uint256(vestingDuration);
        require(cliffEnd <= type(uint64).max, "Cliff timestamp overflow");
        require(vestingEnd <= type(uint64).max, "Vesting timestamp overflow");

        uint256 outstanding = totalAllocated - totalReleased;
        uint256 balance = token.balanceOf(address(this));
        require(balance >= outstanding + amount, "Insufficient funded balance");

        schedules[beneficiary] = VestingSchedule({
            totalAmount: amount,
            released: 0,
            startTime: startTime,
            cliffDuration: cliffDuration,
            vestingDuration: vestingDuration
        });
        totalAllocated += amount;

        emit ScheduleCreated(beneficiary, amount, startTime, cliffDuration, vestingDuration);
    }

    function releasableAmount(address beneficiary) public view returns (uint256) {
        VestingSchedule memory s = schedules[beneficiary];
        if (s.totalAmount == 0) return 0;
        return _vestedAmount(s) - s.released;
    }

    function release() external nonReentrant {
        uint256 amount = releasableAmount(msg.sender);
        require(amount > 0, "No tokens are due for release");

        schedules[msg.sender].released += amount;
        totalReleased += amount;
        token.safeTransfer(msg.sender, amount);

        emit TokensReleased(msg.sender, amount);
    }

    function outstandingObligation() public view returns (uint256) {
        return totalAllocated - totalReleased;
    }

    function availableForNewSchedules() public view returns (uint256) {
        uint256 balance = token.balanceOf(address(this));
        uint256 outstanding = outstandingObligation();
        return balance > outstanding ? balance - outstanding : 0;
    }

    function _vestedAmount(VestingSchedule memory s) private view returns (uint256) {
        uint256 cliffEnd = uint256(s.startTime) + uint256(s.cliffDuration);
        if (block.timestamp < cliffEnd) return 0;

        uint256 vestingEnd = cliffEnd + uint256(s.vestingDuration);
        if (block.timestamp >= vestingEnd) return s.totalAmount;

        uint256 timeElapsed = block.timestamp - cliffEnd;
        return (s.totalAmount * timeElapsed) / uint256(s.vestingDuration);
    }
}
