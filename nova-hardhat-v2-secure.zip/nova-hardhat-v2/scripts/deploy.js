const hre = require("hardhat");

function requireAddress(name) {
  const value = process.env[name];
  if (!value || !hre.ethers.isAddress(value) || value === hre.ethers.ZeroAddress) {
    throw new Error(`${name} must be a valid non-zero EVM address`);
  }
  return value;
}

async function main() {
  const treasury = requireAddress("TREASURY_ADDRESS");
  const vestingOwner = requireAddress("VESTING_OWNER_ADDRESS");
  const [deployer] = await hre.ethers.getSigners();

  if (hre.network.name === "bscMainnet" && vestingOwner === deployer.address) {
    throw new Error("For Mainnet, VESTING_OWNER_ADDRESS must be a dedicated multisig/timelock, not the deployer EOA");
  }

  console.log("Deployer:", deployer.address);
  console.log("Treasury:", treasury);
  console.log("Vesting owner:", vestingOwner);
  console.log("Network:", hre.network.name);

  const NovaToken = await hre.ethers.getContractFactory("NovaToken");
  const token = await NovaToken.deploy(treasury);
  await token.waitForDeployment();

  const NovaTokenVesting = await hre.ethers.getContractFactory("NovaTokenVesting");
  const vesting = await NovaTokenVesting.deploy(await token.getAddress(), vestingOwner);
  await vesting.waitForDeployment();

  console.log("TOKEN_ADDRESS=", await token.getAddress());
  console.log("VESTING_ADDRESS=", await vesting.getAddress());
  console.log(`Verify token: npx hardhat verify --network ${hre.network.name} ${await token.getAddress()} ${treasury}`);
  console.log(`Verify vesting: npx hardhat verify --network ${hre.network.name} ${await vesting.getAddress()} ${await token.getAddress()} ${vestingOwner}`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
