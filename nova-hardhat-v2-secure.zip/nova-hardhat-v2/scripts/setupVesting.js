const hre = require("hardhat");
const config = require("./team-config.json");

const SECONDS_PER_DAY = 24 * 60 * 60;

function assertAddress(address, label) {
  if (!hre.ethers.isAddress(address) || address === hre.ethers.ZeroAddress) {
    throw new Error(`${label} is not a valid non-zero EVM address: ${address}`);
  }
}

function integer(value, label) {
  if (!Number.isInteger(value) || value < 0) throw new Error(`${label} must be a non-negative integer`);
}

async function main() {
  const tokenAddress = process.env.TOKEN_ADDRESS;
  const vestingAddress = process.env.VESTING_ADDRESS;
  if (!tokenAddress || !vestingAddress) throw new Error("TOKEN_ADDRESS and VESTING_ADDRESS are required");
  assertAddress(tokenAddress, "TOKEN_ADDRESS");
  assertAddress(vestingAddress, "VESTING_ADDRESS");

  if (config.tgeTimestamp == null) {
    throw new Error("tgeTimestamp must be explicitly set; refusing to use the current time automatically");
  }
  if (!Number.isSafeInteger(config.tgeTimestamp) || config.tgeTimestamp <= 0) {
    throw new Error("tgeTimestamp must be a positive safe integer Unix timestamp");
  }
  if (!Array.isArray(config.beneficiaries) || config.beneficiaries.length === 0) {
    throw new Error("beneficiaries must be a non-empty array");
  }

  const [admin] = await hre.ethers.getSigners();
  const token = await hre.ethers.getContractAt("NovaToken", tokenAddress);
  const vesting = await hre.ethers.getContractAt("NovaTokenVesting", vestingAddress);
  const decimals = await token.decimals();

  const owner = await vesting.owner();
  if (owner.toLowerCase() !== admin.address.toLowerCase()) {
    throw new Error(`Admin ${admin.address} is not vesting owner ${owner}`);
  }

  const seen = new Set();
  let totalNeeded = 0n;
  const prepared = [];

  for (const b of config.beneficiaries) {
    assertAddress(b.address, `Beneficiary ${b.name}`);
    const key = b.address.toLowerCase();
    if (seen.has(key)) throw new Error(`Duplicate beneficiary: ${b.address}`);
    seen.add(key);

    if (!Number.isSafeInteger(b.amount) || b.amount <= 0) throw new Error(`Invalid amount for ${b.name}`);
    integer(b.cliffMonths, `${b.name}.cliffMonths`);
    integer(b.vestingMonths, `${b.name}.vestingMonths`);
    if (b.vestingMonths <= 0) throw new Error(`${b.name}.vestingMonths must be > 0`);

    const amount = hre.ethers.parseUnits(String(b.amount), decimals);
    const cliffSeconds = BigInt(b.cliffMonths) * BigInt(30 * SECONDS_PER_DAY);
    const vestingSeconds = BigInt(b.vestingMonths) * BigInt(30 * SECONDS_PER_DAY);
    if (cliffSeconds > 2n ** 64n - 1n || vestingSeconds > 2n ** 64n - 1n) {
      throw new Error(`Duration too large for ${b.name}`);
    }

    totalNeeded += amount;
    prepared.push({ b, amount, cliffSeconds, vestingSeconds });
  }

  const existingOutstanding = await vesting.outstandingObligation();
  const balance = await token.balanceOf(vestingAddress);
  if (balance < existingOutstanding + totalNeeded) {
    throw new Error(`Vesting contract is underfunded. Balance=${hre.ethers.formatUnits(balance, decimals)}, required=${hre.ethers.formatUnits(existingOutstanding + totalNeeded, decimals)}`);
  }

  // If the contract already has enough funded tokens, do not move anything.
  // Otherwise the script may optionally fund from the admin EOA, but this is disabled by default.
  const requiredBalance = existingOutstanding + totalNeeded;
  if (balance < requiredBalance) throw new Error("Unexpected funding check failure");

  console.log(`TGE: ${new Date(config.tgeTimestamp * 1000).toISOString()}`);
  console.log(`Total new allocation: ${hre.ethers.formatUnits(totalNeeded, decimals)} NOVA`);
  console.log("Funding is NOT performed automatically. Transfer the required NOVA to the vesting contract first.");

  // Re-check every existing schedule before making any state-changing calls.
  for (const { b } of prepared) {
    const existing = await vesting.schedules(b.address);
    if (existing.totalAmount !== 0n) throw new Error(`Schedule already exists for ${b.address}`);
  }

  for (const { b, amount, cliffSeconds, vestingSeconds } of prepared) {
    const tx = await vesting.createSchedule(
      b.address,
      amount,
      config.tgeTimestamp,
      cliffSeconds,
      vestingSeconds
    );
    await tx.wait();
    console.log(`Created: ${b.name} (${b.address})`);
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
