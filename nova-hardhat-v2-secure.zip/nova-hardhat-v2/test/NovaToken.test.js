const { expect } = require("chai");
const { ethers } = require("hardhat");

const DAY = 24n * 60n * 60n;

async function increaseTo(ts) {
  const block = await ethers.provider.getBlock("latest");
  if (ts > BigInt(block.timestamp)) {
    await ethers.provider.send("evm_setNextBlockTimestamp", [Number(ts)]);
    await ethers.provider.send("evm_mine");
  }
}

describe("NovaToken", function () {
  it("mints exactly the fixed supply to treasury and has no mint path", async function () {
    const [treasury] = await ethers.getSigners();
    const F = await ethers.getContractFactory("NovaToken");
    const token = await F.deploy(treasury.address);
    await token.waitForDeployment();
    expect(await token.totalSupply()).to.equal(100_000_000n * 10n ** 18n);
    expect(await token.balanceOf(treasury.address)).to.equal(await token.totalSupply());
  });

  it("rejects zero treasury", async function () {
    const F = await ethers.getContractFactory("NovaToken");
    await expect(F.deploy(ethers.ZeroAddress)).to.be.revertedWith("Treasury cannot be zero address");
  });
});

describe("NovaTokenVesting", function () {
  async function fixture() {
    const [treasury, owner, founder, team] = await ethers.getSigners();
    const TF = await ethers.getContractFactory("NovaToken");
    const token = await TF.deploy(treasury.address);
    await token.waitForDeployment();
    const VF = await ethers.getContractFactory("NovaTokenVesting");
    const vesting = await VF.deploy(await token.getAddress(), owner.address);
    await vesting.waitForDeployment();
    await token.connect(treasury).transfer(await vesting.getAddress(), 30_000n * 10n ** 18n);
    return { treasury, owner, founder, team, token, vesting };
  }

  it("prevents allocation beyond funded outstanding obligations", async function () {
    const { owner, founder, team, vesting } = await fixture();
    const now = BigInt((await ethers.provider.getBlock("latest")).timestamp);
    await vesting.connect(owner).createSchedule(founder.address, 20_000n * 10n ** 18n, now, 0, 365n * DAY);
    await expect(
      vesting.connect(owner).createSchedule(team.address, 10_001n * 10n ** 18n, now, 0, 365n * DAY)
    ).to.be.revertedWith("Insufficient funded balance");
  });

  it("releases linearly and updates obligations", async function () {
    const { owner, founder, vesting } = await fixture();
    const now = BigInt((await ethers.provider.getBlock("latest")).timestamp);
    const amount = 10_000n * 10n ** 18n;
    const duration = 1000n;
    await vesting.connect(owner).createSchedule(founder.address, amount, now, 100n, duration);

    await increaseTo(now + 99n);
    expect(await vesting.releasableAmount(founder.address)).to.equal(0);
    await increaseTo(now + 600n);
    const due = await vesting.releasableAmount(founder.address);
    expect(due).to.be.gt(0);
    await vesting.connect(founder).release();
    expect(await vesting.totalReleased()).to.equal(due);
    expect(await vesting.outstandingObligation()).to.equal(amount - due);

    await increaseTo(now + 1100n);
    await vesting.connect(founder).release();
    expect(await vesting.outstandingObligation()).to.equal(0);
  });

  it("does not let owner withdraw beneficiary funds", async function () {
    const { owner, founder, token, vesting } = await fixture();
    const now = BigInt((await ethers.provider.getBlock("latest")).timestamp);
    const amount = 10_000n * 10n ** 18n;
    await vesting.connect(owner).createSchedule(founder.address, amount, now, 0, 1000);
    expect(await token.balanceOf(owner.address)).to.equal(0);
  });
});
